#!/usr/bin/env python
from patroni import main


if __name__ == '__main__':
    main()
